#include <stdio.h>
#include <stdlib.h>
#include "solve.h"

void solve(int n , int ** graph ){
  int **q,i,j,**next;
  next=calloc(n,sizeof(int *)); //initializes both Q and Next arrays
  q=calloc(n,sizeof(int *));{
    if(q==NULL)
      printf("Q null\n");
    if(next==NULL)
      printf("Nexcleart null\n");
    for( i=0;i<n;i++){
      next[i]=calloc(n,sizeof(int *));
      q[i]=calloc(n,sizeof(int *));
      if(q[i]==NULL)
        printf("Q[%d] Null\n",i);
      if(next[i]==NULL)
        printf("next[%d] null \n",i );
    }
  }
  for(i=0; i<n; i++)
    for(j=0; j<i; j++){
      q[j][i]=q[i][j]=graph[i][j]; //copies the costs from graph array to q twice so the array wont be triangular
      next[i][j]=j; //initializes the
      next[j][i]=i;
    }

  for(int k=0; k<n; k++)
    for(i=1; i<n; i++)
      for(j=0; j<i; j++){
        if(i==j)
          continue; //ignores the process if i=j
        if( q[i][k]!= -1 && q[k][j]!= -1 ){ //if i-k and k-j nodes exist
          if( q[i][j] > q[i][k] + q[k][j] || q[i][j]==-1 ){ //compares the costs of node i-j with i-k+k-j
            q[i][j]= q[i][k] + q[k][j] ; //replaces the cost if its quicker to go through node k
            next[i][j]=k;
            next[j][i]=k;
            }
          }
        }
  for(i=1; i<n; i++){
    for(j=0; j<i; j++){
      if(q[i][j]==-1){
        printf("From node %d to node %d = There is no path.\n",i,j );
        continue;
      }
      printf("From node %d to node %d = %d \n",i,j,q[i][j]);
      #ifdef PATH //prints the nodes each list includes
        printf("\tShortest path is :");
        if(next[i][j]==j)
          printf("%d -> ",i );
        else{
          int u=i;
          while(u!=j){
            printf("%d ->",u );
            u=next[u][j];
          }
        }
        printf("%d\n",j );
      #endif
    }
    printf("\n" );
  }
 for (i=0 ; i<n ; i++){
   free(q[i]);
   free(next[i]);
 }
 free(q);
 free (next);
}
