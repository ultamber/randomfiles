#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "solve.h"

int main(){
  int a,i ,**px,x,N;
  scanf("%d",&N);
  px=malloc(N*sizeof(int *));
  if(px==NULL)
    return -1;
  for( i = 0 ; i < N ; i++ ){
    px[i]=malloc((i+1)*sizeof(int *));
    if(px[i]==NULL)
      return -1;
    for(x=0;x<i;x++){
      scanf("%d",&a );
      px[i][x]=a;
    }
  }
  printf("\n");
  solve(N,px);
  for (i=0 ; i < N ; i++)
    free(px[i]);
  free(px);
 }
