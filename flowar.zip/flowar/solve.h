void solve(int n, int **graph);
