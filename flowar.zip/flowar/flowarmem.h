void solve(int n, int **graph);
int path(int i,int j,int k,int **graph,int ***gr);
int cost(int i ,int j,int **graph);
int min(int a,int b,int c, int **graph,int ***gr);
