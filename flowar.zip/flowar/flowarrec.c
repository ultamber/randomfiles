#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "flowarrec.h"

#define INF -1

void solve(int n , int **graph){
  for(int i=1 ; i<n ; i++){
    for(int j=0 ; j<i ; j++){
        int c=path(i,j,n-1,graph);
        printf("From node %d to node %d : Length of shortest path is %d\n",i,j,c);
      }
      printf("\n");
  }
}

int path(int i,int j,int k,int **graph){
  if(k<0)
    return cost(i,j,graph);
  else
    return min(i,j,k,graph);
}

int cost(int i ,int j,int **graph){
  if(i>j)
    return graph[i][j];
  else if(i<j)
    return graph[j][i];
  else
    return 0;
}

int min(int i,int j,int k,int **graph){//compares i-j node with i-k+k-j and returns the minimum
  int b;
  int a=path(i,j,k-1,graph);
  int b1=path(i,k,k-1,graph);
  int b2=path(k,j,k-1,graph);
  if(b1==INF||b2==INF)
    return a;
  else
    b=b1+b2;
  if(a==INF)
    return b;
  return a>b?b:a;
}
