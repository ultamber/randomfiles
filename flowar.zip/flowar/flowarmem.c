#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "flowarmem.h"

void solve(int n , int **graph){
  int ***gr; //initialization of array gr till line ~20
  gr=calloc(n,sizeof(int *));
  if(gr==NULL)
    printf("Null\n");
  for(int i=0;i<n;i++){
    gr[i]=calloc(n,sizeof(int *));
    if(gr[i]==NULL)
      printf("Null\n");
    for(int j=0;j<n;j++){
      gr[i][j]=calloc(n,sizeof(int *));
      if(gr[i][j]==NULL)
        printf("Null\n");
      }
    }
  for(int i=1 ; i<n ; i++){
    printf("\n");
    for(int j=0 ; j<i ; j++){
        int c=path(i,j,n-1,graph,gr); //calculates for each i-j the path
        printf("From node %d to node %d : Length of shortest path is %d\n",i,j,c);
      }
  }
}

int path(int i,int j,int k,int **graph,int ***gr){
  if(gr[i][j][k]==0){
    if(k<0)
      return cost(i,j,graph);
    else{
      int m=min(i,j,k,graph,gr); //compares the costs and returns the minimum
      gr[i][j][k]=m;  //updates gr array
      return m;
    }
  }
  else
    return gr[i][j][k];
}

int cost(int i ,int j,int **graph){ //returns the cost from node i to node j from the array graph
  if(i>j)
    return graph[i][j];
  else if(i<j)
    return graph[j][i];
  else
    return 0;
}

int min(int i,int j,int k,int **graph,int ***gr){
  int b;
  int a=path(i,j,k-1,graph,gr); //calls path function 3 times for each i-j , i-k and k-j
  int b1=path(i,k,k-1,graph,gr);
  int b2=path(k,j,k-1,graph,gr);
  if(b1==-1||b2==-1) //if one of the nodes i-k and k-j doesnt exist
    return a;
  else //calculates the cost of them if they both exist
    b=b1+b2;
  if(a==-1)
    return b;
  return a>b?b:a; //returns which cost is smaller
}
